//
//  GGNewsCell.h
//  GameGeek
//
//  Created by qianfeng on 15/10/9.
//  Copyright (c) 2015年 qianfeng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GGNewsHomeModel.h"

@interface GGNewsCell : UITableViewCell

-(void)setUIWith:(GGNewsHomeSecondModel *)info;

@end
