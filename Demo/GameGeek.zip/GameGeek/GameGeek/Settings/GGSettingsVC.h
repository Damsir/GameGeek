//
//  GGSettingsVC.h
//  GameGeek
//
//  Created by qianfeng on 15/10/12.
//  Copyright (c) 2015年 qianfeng. All rights reserved.
//

#import "BaseViewController.h"

@interface GGSettingsVC : UIViewController

@end
