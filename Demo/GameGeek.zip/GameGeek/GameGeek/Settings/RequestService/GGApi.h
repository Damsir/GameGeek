//
//  GGApi.h
//  GameGeek
//
//  Created by qianfeng on 15/10/9.
//  Copyright (c) 2015年 qianfeng. All rights reserved.
//

#ifndef GameGeek_GGApi_h
#define GameGeek_GGApi_h

#define GG_NEWS_HOST @"http://api.wegame.app887.com/api/Articles.action"

//?keyword=&npc=0&opc=20&type=%E6%9C%80%E6%96%B0%E9%B2%9C&uid=36729

#define GG_VIDEO_HOST @"http://api.wegame.app887.com/api/Articles.action"

//?npc=0&opc=20&type=%E5%8E%9F%E7%94%9F&uid=36729

#define GG_STRATEGY_HOST @"http://api.wegame.app887.com/api/Articles.action"

//?npc=0&opc=20&type=%E6%94%BB%E7%95%A5&uid=36729

#define GG_LIST_HOST @"http://api.wegame.app887.com/api/Externals.action"

//?kind=PlayStation&npc=0&opc=20&sorttype=0

#define GG_LIST_NEXT_PAGE @"http://api.wegame.app887.com/api/Articles.action"
//?keyword=%E9%BB%91%E6%9A%97%E4%B9%8B%E9%AD%823&npc=0&opc=20&uid=36729

#endif
