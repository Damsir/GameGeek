//
//  GGVideoHomeModel.m
//  GameGeek
//
//  Created by qianfeng on 15/10/10.
//  Copyright (c) 2015年 qianfeng. All rights reserved.
//

#import "GGVideoHomeModel.h"

@implementation GGVideoHomeModel

@end
