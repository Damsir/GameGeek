//
//  GGListNextPage.h
//  GameGeek
//
//  Created by qianfeng on 15/10/11.
//  Copyright (c) 2015年 qianfeng. All rights reserved.
//

#import "BaseViewController.h"

@interface GGListNextPage : BaseViewController

//传入keyword 以拼接下一页面api
ProStr(keywordName);

@end
